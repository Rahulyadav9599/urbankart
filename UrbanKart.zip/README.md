# UrbanKart

Multi-category e-commerce store built with React and Tailwind CSS.